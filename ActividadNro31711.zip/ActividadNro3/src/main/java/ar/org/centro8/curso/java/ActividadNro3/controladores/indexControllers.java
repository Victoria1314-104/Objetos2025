package ar.org.centro8.curso.java.ActividadNro3.controladores;

import org.springframework.web.bind.annotation.GetMapping;

public class indexControllers {
        
    @GetMapping("index")
    public String getIndex(){
        return "index";
    }
    
}

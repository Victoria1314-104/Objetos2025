package ar.org.centro8.curso.java.ActividadNro3.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public final class Connector {

    private static Connection conn=null;

    // //MariaDB
    // private static String url="jdbc:mariadb://localhost:3306/restaurante";
    // private static String user="root";
    // private static String pass="";

    // SQLite
    private static String url="jdbc:sqlite:data/data.bd";
    private static String user="root";
    private static String pass="";

    private Connector(){}

    public static String getUrl(){
        return url;
    }

    public synchronized static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }

}

package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;

public class TestProveedor {
    public static void main(String[] args) {
        System.out.println("--- proveedor 1---");
        Proveedor proveedor1=new Proveedor(1, "Carniceria RES", "Av.boedo 781", "1122334455");
        System.out.println(proveedor1);
    }
}

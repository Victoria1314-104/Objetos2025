package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;
import ar.org.centro8.curso.java.ActividadNro3.repositories.InsumoRepository;

public class TestInsumoRepository {
    public static void main(String[] args) {
        InsumoRepository ir = new InsumoRepository();

        Insumo insumo = new Insumo("Papa negra", "kg", 23.65,100);
        ir.save(insumo);
        System.out.println(insumo);

        ir.remove(ir.getById_Insumo(1));

        System.out.println("----------------------------");
        ir.getAll().forEach(System.out::println);

        System.out.println("----------------------------");
        ir.getLikeProducto("za").forEach(System.out::println);
    }
}

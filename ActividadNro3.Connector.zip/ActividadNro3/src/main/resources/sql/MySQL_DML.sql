use restaurante;
-- 1. Proveedores
INSERT INTO proveedores (nombre, direccion, telefono_proveedor) VALUES
('Frutas y Verduras La Huerta', 'Av. Córdoba 123, CABA', '11334455'),
('Carnes El Buen Corte', 'Calle Mendoza 45, Mendoza', '26123456'),
('Lácteos Don Quesito', 'Calle San Martín 78, Rosario', '34133455'),
('Panadería La Espiga', 'Av. Libertador 210, CABA', '11445566'),
('Salsas y Condimentos Delicias', 'Calle Rivadavia 150, La Plata', '22156677'),
('Aceites y Aderezos Oro Verde', 'Av. Callao 300, CABA', '11778899'),
('Bebidas y Jugos Naturales', 'Calle Belgrano 400, Córdoba', '35177889'),
('Café y Té La Aroma', 'Av. Santa Fe 500, CABA', '11990011'),
('Harinas y Azúcares Molino Real', 'Calle Uruguay 60, Mendoza', '26190112'),
('Verdulería El Jardín', 'Calle Pueyrredón 77, CABA', '11101010'),
('Carnes Premium Angus', 'Calle Corrientes 88, Rosario', '34121212'),
('Quesería La Suiza', 'Av. Dorrego 99, CABA', '11313131'),
('Panadería Artesanal Trigo y Miel', 'Calle Junín 110, La Plata', '22141414'),
('Distribuidora de Lácteos Frescura', 'Av. Independencia 120, Mendoza', '26151515'),
('Frutas Tropicales La Palma', 'Calle Catamarca 130, CABA', '16161616'),
('Pollería El Gallo Dorado', 'Av. Maipú 140, Córdoba', '35171717'),
('Aceites Premium Olivetto', 'Calle Salta 150, CABA', '18181818'),
('Tés e Infusiones AromaZen', 'Av. Rivadavia 160, La Plata', '22191919'),
('Bebidas Saludables VitalDrink', 'Calle Tucumán 170, Rosario', '34120202'),
('Delicatessen Sabores del Mundo', 'Av. Santa Fe 180, CABA', '11212121');

-- Insumos
INSERT INTO insumos (id_insumos, producto, cantidad_venta) VALUES
(1,'Zanahoria','kg'),
(2,'Papa','kg'),
(3,'Zapallo','kg'),
(4,'Sandia','unidad'),
(5,'Manzana','kg'),
(6,'Lechuga','unidad'),
(7,'Tomate','kg'),
(8,'Cebolla','kg'),
(9,'Queso','kg'),
(10,'Leche','litro'),
(11,'Pan','unidad'),
(12,'Aceite','litro'),
(13,'Azúcar','kg'),
(14,'Harina','kg'),
(15,'Café','kg'),
(16,'Té','kg'),
(17,'Jugo de Naranja','litro'),
(18,'Pollo','kg'),
(19,'Carne de Res','kg'),
(20,'Salsa de Tomate','litro');

-- Proveedor_insumos
INSERT INTO proveedor_insumos (id_proveedores, id_insumos, precio, stock, descripcion) VALUES
(1,1,150.00,50,'Zanahoria fresca de CABA'),
(1,2,120.00,40,'Papa nueva de CABA'),
(2,1,160.00,30,'Zanahoria premium de Mendoza'),
(2,3,200.00,25,'Zapallo de Mendoza'),
(3,5,300.00,20,'Manzanas rojas'),
(4,11,50.00,100,'Pan integral fresco'),
(5,12,400.00,60,'Aceite de oliva extra virgen'),
(6,15,1200.00,30,'Café orgánico'),
(7,17,250.00,40,'Jugo natural'),
(8,16,800.00,25,'Té importado'),
(9,13,90.00,70,'Azúcar refinada'),
(10,6,60.00,50,'Lechugas frescas'),
(11,19,1200.00,35,'Carne de res premium'),
(12,9,950.00,40,'Queso gouda'),
(13,14,100.00,80,'Harina 000'),
(14,10,200.00,100,'Leche fresca'),
(15,4,350.00,30,'Sandías grandes'),
(16,18,500.00,45,'Pollo orgánico'),
(17,12,380.00,55,'Aceite de girasol'),
(18,16,750.00,20,'Té verde premium');

--Turnos
INSERT INTO turnos (dia, horario) VALUES
('LUNES','08:00-16:00'),
('MARTES','08:00-16:00'),
('MIERCOLES','12:00-20:00'),
('JUEVES','12:00-20:00'),
('VIERNES','10:00-18:00');

-- Empleados
INSERT INTO empleados (nombre, apellido, direccion, telefono, legajo, id_turno) VALUES
('Juan','Pérez','Calle Falsa 123, CABA','11223344','L001',1),
('María','Gómez','Av. Siempre Viva 742, CABA','11445566','L002',1),
('Carlos','Rodríguez','Calle Córdoba 456, Mendoza','26123456','L003',2),
('Laura','Fernández','Calle Mendoza 789, Mendoza','26134567','L004',2),
('Lucía','Martínez','Av. Santa Fe 321, CABA','11990011','L005',3),
('Jorge','González','Calle Belgrano 55, Córdoba','35177889','L006',3),
('Sofía','López','Calle Uruguay 67, Rosario','34133455','L007',4),
('Diego','Sánchez','Av. Libertador 89, CABA','11445577','L008',4),
('Valentina','Torres','Calle Rivadavia 12, La Plata','22156677','L009',5),
('Martín','Ramírez','Calle Salta 34, CABA','18181818','L010',5),
('Camila','Vargas','Av. Dorrego 45, CABA','11313131','L011',1),
('Facundo','Castro','Calle Junín 67, La Plata','22141414','L012',2),
('Agustina','Rojas','Av. Independencia 89, Mendoza','26151515','L013',3),
('Tomás','Molina','Calle Catamarca 101, CABA','16161616','L014',4),
('Emilia','Alvarez','Av. Maipú 111, Córdoba','35171717','L015',5),
('Bruno','Fernández','Calle Salta 121, CABA','18181818','L016',1),
('Paula','Giménez','Av. Rivadavia 141, La Plata','22191919','L017',2),
('Santiago','Morales','Calle Tucumán 161, Rosario','34120202','L018',3),
('Valeria','Herrera','Av. Santa Fe 181, CABA','11212121','L019',4),
('Nicolás','Juárez','Calle Córdoba 200, CABA','11334455','L020',5);
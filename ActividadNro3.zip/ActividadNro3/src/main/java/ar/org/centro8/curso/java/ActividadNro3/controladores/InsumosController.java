package ar.org.centro8.curso.java.ActividadNro3.controladores;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;
import ar.org.centro8.curso.java.ActividadNro3.repositories.InsumoRepository;
import ar.org.centro8.curso.java.ActividadNro3.repositories.ProveedorRepository;

@Controller
public class InsumosController {
    private InsumoRepository ir = new InsumoRepository();
    private ProveedorRepository pr = new ProveedorRepository();
    private String mensaje="Complete las celdas";

    @GetMapping("/insumos")
    public String getInsumo(Model model, @RequestParam(name="buscar", defaultValue = "") String buscar) {
        Insumo insumo =new Insumo();
        model.addAttribute("insumo", insumo);
        model.addAttribute("proveedores", pr.getAll());
        if (buscar.matches("\\d+")) {
            Insumo encontrado = ir.getById_Insumo(Integer.parseInt(buscar));
            model.addAttribute("insumos", List.of(encontrado));
        } else {
            model.addAttribute("insumos", ir.getLikeProducto(buscar));
        }
        model.addAttribute("mensaje", mensaje);
        return "insumos";
    }

    @PostMapping("/guardarInsumo")
    public String guardarInsumo(@ModelAttribute Insumo insumo) {
        ir.save(insumo);
        if (insumo.getId_insumos()>0) mensaje="Se guardo el producto. Su id es " + insumo.getId_insumos();
        else mensaje="No se guardo el producto";
        return "redirect:/insumos";
    }
}


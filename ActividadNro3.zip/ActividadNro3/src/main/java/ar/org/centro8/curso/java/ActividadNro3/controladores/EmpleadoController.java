package ar.org.centro8.curso.java.ActividadNro3.controladores;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;
import ar.org.centro8.curso.java.ActividadNro3.repositories.EmpleadoRepository;

@Controller
public class EmpleadoController {
    private EmpleadoRepository er = new EmpleadoRepository();
    private String mensaje = "Complete las celdas";

    @GetMapping("/empleados")
    public String getEmpleado(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        Empleado empleado = new Empleado();
        model.addAttribute("empleado", empleado);
        model.addAttribute("dias", List.of(Dia.values()));
        model.addAttribute("horarios", List.of(Horario.values()));
        if (buscar.matches("\\d+")) {
            Empleado encontrado = er.getById_empleado(Integer.parseInt(buscar));
            model.addAttribute("empleados", List.of(encontrado));
        } else {
            model.addAttribute("empleados", er.getLikeApellido(buscar));
        }
        model.addAttribute("mensaje", mensaje);
        return "empleados";
    }

    @PostMapping("/guardarEmpleado")
    public String guardarEmpleado(@ModelAttribute Empleado empleado) {
        er.save(empleado);
        if (empleado.getId_empleado() > 0)
            mensaje = "Se guardo el empleado. Su id es" + empleado.getId_empleado();
        else
            mensaje = "No se guardo el empleado";
        return "redirect:/empleados";
    }

    @GetMapping("/eliminarEmpleado")
    public String eliminarEmpleado(@ModelAttribute Empleado empleado) {
        er.remove(empleado);
        if (empleado.getId_empleado() > 0) {
            er.remove(empleado);
            mensaje = "Empleado eliminado correctamente";
        } else {
            mensaje = "El empleado con ID " + empleado.getId_empleado() + " no existe";
        }
        return "redirect:/empleados";
    }

}

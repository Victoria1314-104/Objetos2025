package ar.org.centro8.curso.java.ActividadNro3.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.ActividadNro3.connectors.Connector;
import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;

public class EmpleadoRepository {
    private Connection conn = Connector.getConnection();

    public void save(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleados (nombre, apellido, fecha_ingreso, direccion, telefono, legajo, dia, horario) values (?,?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setString(3, empleado.getFecha_ingreso());
            ps.setString(4, empleado.getDireccion());
            ps.setString(5, empleado.getTelefono());
            ps.setString(6, empleado.getLegajo());
            ps.setString(7, empleado.getDia().toString());
            ps.setString(8, empleado.getHorario().toString());
            // ps.setInt(6, empleado.getId_turno();
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleado.setId_empleado(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from empleados where id_empleado=?")) {
            ps.setInt(1, empleado.getId_empleado());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Empleado getById_empleado(int id_empleado) {
        return getAll()
                .stream()
                .filter(e -> e.getId_empleado() == id_empleado)
                .findAny()
                .orElse(new Empleado());
    }

    public List<Empleado> getAll() {
        List<Empleado> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from empleados")) {
            while (rs.next()) {
                list.add(
                        new Empleado(rs.getInt("id_empleado"),
                                rs.getString("nombre"),
                                rs.getString("apellido"),
                                rs.getString("fecha_ingreso"),
                                rs.getString("direccion"),
                                rs.getString("telefono"),
                                rs.getString("legajo"),
                                Dia.valueOf(rs.getString("dia")),
                                Horario.valueOf(rs.getString("horario"))));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Empleado> getLikeNombre(String nombre) {
        return getAll()
                .stream()
                .filter(e -> e.getNombre().toLowerCase().contains(nombre))
                .toList();
    }

    public List<Empleado> getLikeApellido(String apellido) {
        return getAll()
                .stream()
                .filter(e -> e.getApellido().toLowerCase().contains(apellido))
                .toList();
    }

    public List<Empleado> getLikeFecha_ingreso(String fecha_ingreso) {
        return getAll()
                .stream()
                .filter(e -> e.getFecha_ingreso() == fecha_ingreso)
                .toList();
    }

    public List<Empleado> getLikeDireccion(String direccion) {
        return getAll()
                .stream()
                .filter(e -> e.getDireccion().toLowerCase().contains(direccion))
                .toList();
    }

    public List<Empleado> getLikeTelefono(String telefono) {
        return getAll()
                .stream()
                .filter(e -> e.getTelefono().toLowerCase().contains(telefono))
                .toList();
    }

    public List<Empleado> getLikeLegajo(String legajo) {
        return getAll()
                .stream()
                .filter(e -> e.getLegajo().toLowerCase().contains(legajo))
                .toList();
    }

    // public Empleado getLikeId_turno(int id_turno) {
    // return getAll()
    // .stream()
    // .filter(t->t.getId_turno == id_turno)
    // .findAny()
    // .orElse(null);
    // }

}

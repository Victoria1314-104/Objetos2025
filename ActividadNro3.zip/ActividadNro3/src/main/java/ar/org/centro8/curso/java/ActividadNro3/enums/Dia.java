package ar.org.centro8.curso.java.ActividadNro3.enums;

public enum Dia {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES,
    VIERNES
}


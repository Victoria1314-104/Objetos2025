package ar.org.centro8.curso.java.entities;

public final class Radio {
    public String marcaRadio;
    public double potencia;

    public Radio(String marca, double potencia) {
        this.marcaRadio = marca;
        this.potencia = potencia;
    }

    public String getMarca() {
        return marcaRadio;
    }

    public void setMarca(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    public double getPotencia() {
        return potencia;
    }

    public void setPotencia(double potencia) {
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        return "Radio [marca=" + marcaRadio + ", potencia=" + potencia + "]";
    }

}

package ar.org.centro8.curso.java.entities;

public final class Colectivo extends Vehiculo {

    public Colectivo(String color, String marca, String modelo, double precio, String marcaRadio, Double potencia) {
        super(color, marca, modelo, precio, marcaRadio, potencia);
    }

    public Colectivo(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public String toString() {
        return "Colectivo [" + super.toString() + "]";
    }


}

package ar.org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String color, String marca, String modelo, double precio, String marcaRadio, double potencia) {
        super(color, marca, modelo, precio, marcaRadio, potencia);
        if (marcaRadio == null && potencia==0) {
            System.out.println("Un AutoNuevo no puede quedarse sin radio.");
        }
    }

    @Override
    public String toString() {
        return "AutoNuevo [" + super.toString() + "]";
    }

}

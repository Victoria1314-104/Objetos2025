package ar.org.centro8.curso.java.entities;

public abstract class Vehiculo {
    public String color;
    public String marca;
    public String modelo;
    public double precio;
    public Radio radio;

    public Vehiculo(String color, String marca, String modelo, double precio, Radio radio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio = radio;
    }

    public Vehiculo(String color, String marca, String modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

    public void cambiarRadio(Radio radio) {
        this.radio=radio;
    };

}

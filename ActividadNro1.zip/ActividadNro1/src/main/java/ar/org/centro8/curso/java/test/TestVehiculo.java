package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Colectivo;
import ar.org.centro8.curso.java.entities.Radio;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("---Vehiculo---");
        System.out.println("-------------------------");

        System.out.println(">>> autoNuevo1 <<<");
        AutoNuevo autonuevo1=new AutoNuevo("celeste", "Honda", "HPV", 1200000, new Radio("X", 10000));
        System.out.println(autonuevo1);
        System.out.println(">>> autoNuevo1.cambiarRadio <<<");
        autonuevo1.cambiarRadio(new Radio("A", 20000));
        System.out.println(autonuevo1);
        System.out.println("-------------------------");

        System.out.println(">>> colectivo1 <<<");
        Colectivo colectivo1= new Colectivo("azul y blanco", "mercedes", "colectivo", 1000000, null);
        System.out.println(colectivo1);
        System.out.println(">>> colectivo2 <<<");
        Colectivo colectivo2= new Colectivo("55", "Mercedes", "Automatico", 5750000);
        System.out.println(colectivo2);
        System.out.println(">>> colectivo2.cambiarRadio");
        colectivo2.cambiarRadio(new Radio("B", 2400));
        System.out.println(colectivo2);
        System.out.println("-------------------------");


        System.out.println("-- radio --");
        System.out.println(">>> radio1 <<<");
        Radio radio1= new Radio("italy", 3000);
        System.out.println(radio1);

    }
}

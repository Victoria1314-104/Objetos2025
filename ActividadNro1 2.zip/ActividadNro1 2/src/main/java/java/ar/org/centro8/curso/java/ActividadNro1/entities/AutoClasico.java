package java.ar.org.centro8.curso.java.ActividadNro1.entities;

public class AutoClasico extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio, radio);
    }

    public AutoClasico(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public String toString() {
        return "AutoNuevo [" + super.toString() + "]";
    }

    @Override
    public void cambiarRadio(Radio nuevaRadio) {
        if (nuevaRadio == null) {
            System.out.println("Un AutoNew no puede quedarse sin radio.");
        } else {
            super.cambiarRadio(nuevaRadio);
        }
    }
}

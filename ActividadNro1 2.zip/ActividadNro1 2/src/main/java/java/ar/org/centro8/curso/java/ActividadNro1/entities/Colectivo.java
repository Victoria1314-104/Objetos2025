package java.ar.org.centro8.curso.java.ActividadNro1.entities;

public final class Colectivo extends Vehiculo {

    public Colectivo(String color, String marca, String modelo, double precio, Radio radio) {
        super(color, marca, modelo, precio, radio);
    }

    public Colectivo(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public String toString() {
        return "Colectivo [" + super.toString() + "]";
    }

}

package java.ar.org.centro8.curso.java.ActividadNro1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActividadNro1Application {

	public static void main(String[] args) {
		SpringApplication.run(ActividadNro1Application.class, args);
	}

}

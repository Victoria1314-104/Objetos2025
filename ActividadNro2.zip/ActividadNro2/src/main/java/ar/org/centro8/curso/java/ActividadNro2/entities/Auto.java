package ar.org.centro8.curso.java.ActividadNro2.entities;
// import ar.org.centro8.curso.java.ActividadNro2.entities.Vehiculo;

public class Auto extends Vehiculo{

    public Auto(String Marca, String Modelo, double Puertas, double Precio) {
        super(Marca, Modelo, Puertas, Precio);
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Puertas = Puertas;
        this.Precio = Precio;
    }

    // @Override
    // public String toString() {
    //     return "Auto [" + super.toString() + "]";
    // }
    
}

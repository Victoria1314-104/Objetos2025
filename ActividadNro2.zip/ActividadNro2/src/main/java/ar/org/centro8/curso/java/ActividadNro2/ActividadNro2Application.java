package ar.org.centro8.curso.java.ActividadNro2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActividadNro2Application {

	public static void main(String[] args) {
		SpringApplication.run(ActividadNro2Application.class, args);
	}

}

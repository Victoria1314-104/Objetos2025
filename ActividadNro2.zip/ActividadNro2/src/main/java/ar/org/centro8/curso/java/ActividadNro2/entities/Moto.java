package ar.org.centro8.curso.java.ActividadNro2.entities;

public class Moto extends Vehiculo {
    public Moto(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, cilindrada, precio);
        Marca = marca;
        Modelo = modelo;
        Cilindrada = cilindrada;
        Precio = precio;
    }

    // @Override
    // public String toString() {
    //     return "Moto [" + super.toString() + "]";
    // }

}

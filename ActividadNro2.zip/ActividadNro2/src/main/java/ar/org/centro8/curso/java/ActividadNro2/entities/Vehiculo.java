package ar.org.centro8.curso.java.ActividadNro2.entities;

import java.text.DecimalFormat;
import lombok.AllArgsConstructor;
import lombok.Data;

// import jakarta.annotation.sql.DataSourceDefinition;

@Data
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo>{
    public String Marca;
    public String Modelo;
    public double Precio;

    
    
    // public Vehiculo(String marca, String modelo, String Cilindrada, double precio) {
    //     Marca = marca;
    //     Modelo = modelo;
    //     this.Cilindrada = Cilindrada;
    //     Precio = precio;
    // }

    // public Vehiculo(String marca, String modelo, int Puertas, double precio) {
    //     Marca = marca;
    //     Modelo = modelo;
    //     Puertas = Puertas;
    //     Precio = precio;
    // }

    @Override
    public int compareTo(Vehiculo para){
        DecimalFormat df=new DecimalFormat();
        String thisVehiculo=this.getMarca()+"//"+this.getModelo()+"//"+"//"+df.format(this.getPrecio());
        String paraVehiculo=para.getMarca()+"//"+para.getModelo()+"//"+"//"+df.format(para.getPrecio());
        return thisVehiculo.compareTo(paraVehiculo);
    }

}

    
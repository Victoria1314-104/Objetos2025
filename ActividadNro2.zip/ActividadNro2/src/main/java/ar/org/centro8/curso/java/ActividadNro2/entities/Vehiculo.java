package ar.org.centro8.curso.java.ActividadNro2.entities;

import java.text.DecimalFormat;
import lombok.AllArgsConstructor;
import lombok.Data;

// import jakarta.annotation.sql.DataSourceDefinition;

@Data
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo>{
    public String Marca;
    public String Modelo;
    public String Cilindrada;
    public double Puertas;
    public double Precio;
    
    public Vehiculo(String marca, String modelo, String cilindrada, double precio) {
        Marca = marca;
        Modelo = modelo;
        Cilindrada = cilindrada;
        Precio = precio;
    }

    public Vehiculo(String marca, String modelo, double puertas, double precio) {
        Marca = marca;
        Modelo = modelo;
        Puertas = puertas;
        Precio = precio;
    }

    @Override
    public int compareTo(Vehiculo para){
        DecimalFormat df=new DecimalFormat();
        String thisVehiculo=this.getMarca()+"//"+this.getModelo()+"//"+this.getPuertas()+"//"+df.format(this.getPrecio());
        String paraVehiculo=para.getMarca()+"//"+para.getModelo()+"//"+para.getPuertas()+"//"+df.format(para.getPrecio());
        return thisVehiculo.compareTo(paraVehiculo);
    }

}

    
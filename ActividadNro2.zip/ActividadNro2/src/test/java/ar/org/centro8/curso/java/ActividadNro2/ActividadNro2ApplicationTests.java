package ar.org.centro8.curso.java.ActividadNro2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadNro2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

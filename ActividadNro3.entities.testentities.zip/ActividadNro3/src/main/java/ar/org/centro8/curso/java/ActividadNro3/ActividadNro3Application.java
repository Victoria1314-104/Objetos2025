package ar.org.centro8.curso.java.ActividadNro3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActividadNro3Application {

	public static void main(String[] args) {
		SpringApplication.run(ActividadNro3Application.class, args);
	}

}

package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;
import ar.org.centro8.curso.java.ActividadNro3.entities.Provedor_insumo;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;

public class TestProveedor_Insumo {
    public static void main(String[] args) {
        System.out.println("---proveedorInsumo1---");
        Provedor_insumo proveedorInsumo1 = new Provedor_insumo(new Proveedor(1, "RES-Almagro", "Calle", null), new Insumo(1, "Asado", "kg", 25000, 25), null);
        System.out.println(proveedorInsumo1);
    }
}

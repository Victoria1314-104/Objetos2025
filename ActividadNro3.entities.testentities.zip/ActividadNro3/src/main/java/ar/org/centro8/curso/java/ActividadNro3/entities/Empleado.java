package ar.org.centro8.curso.java.ActividadNro3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Empleado {
    private int id_empleado;
    private String nombre;
    private String apellido;
    private LocalDate fecha_ingreso = LocalDate.now();
    private String direccion;
    private String legajo;
    private Turno id_turno;

    @Override
    public String toString() {
        return "Empleado [id_empleado=" + id_empleado + ", nombre=" + nombre + ", apellido=" + apellido
                + ", fecha_ingreso=" + fecha_ingreso + ", direccion=" + direccion + ", legajo=" + legajo + ", id_turno="
                + id_turno.getId_turno() + "]";
    }
}



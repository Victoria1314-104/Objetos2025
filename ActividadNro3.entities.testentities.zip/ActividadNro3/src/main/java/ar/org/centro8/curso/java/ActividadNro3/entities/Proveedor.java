package ar.org.centro8.curso.java.ActividadNro3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Proveedor {
    private int id_proveedor;
    private String nombre;
    private String direccion;
    private String telefono_proveedor;
}

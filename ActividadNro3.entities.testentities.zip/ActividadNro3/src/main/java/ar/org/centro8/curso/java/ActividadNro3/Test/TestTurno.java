package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Turno;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;

public class TestTurno {
    public static void main(String[] args) {
        System.out.println("---tuno1---");
        Turno turno1 = new Turno(1, Dia.LUNES, Horario.MAÑANA);
        System.out.println(turno1);
    }
}

package ar.org.centro8.curso.java.ActividadNro3.entities;

import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Turno {
    private int id_turno;
    private Dia dia;
    private Horario horario;
    
}

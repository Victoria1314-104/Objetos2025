package ar.org.centro8.curso.java.ActividadNro3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Insumo {
    private int id_insumo;
    private String producto;
    private String cantidad_venta;
    private double precio;
    private int stock;
}

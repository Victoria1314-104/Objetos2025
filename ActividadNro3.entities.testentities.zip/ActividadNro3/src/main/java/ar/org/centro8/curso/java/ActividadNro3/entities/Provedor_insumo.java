package ar.org.centro8.curso.java.ActividadNro3.entities;

// import lombok.AllArgsConstructor;
// import lombok.Data;
// import lombok.NoArgsConstructor;

// @Data
// @NoArgsConstructor
// @AllArgsConstructor
public class Provedor_insumo {
    private Proveedor id_proveedor;
    private Insumo id_insumo;
    private String descripcion;

    public Provedor_insumo(Proveedor id_proveedor, Insumo id_insumo, String descripcion) {
        // super(id_proveedor, id_insumos,precio, stock, descripcion);
        this.id_proveedor = id_proveedor;
        this.id_insumo = id_insumo;
        this.descripcion = descripcion;
    }

    public Proveedor getProveedor() {
        return id_proveedor;
    }

    public Insumo getInsumo() {
        return id_insumo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return "Provedor_insumo [id_proveedor=" + id_proveedor.getId_proveedor() + ", id_insumo=" + id_insumo.getId_insumo() + ", precio=" + id_insumo.getPrecio() + ", stock="
                + id_insumo.getStock() + ", descripcion=" + descripcion + "]";
    }




    
}

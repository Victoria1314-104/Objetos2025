package ar.org.centro8.curso.java.ActividadNro2.entities;

public class Moto extends Vehiculo {
    public String Cilindrada;

    public Moto(String marca, String modelo, String Cilindrada, double precio) {
        super(marca, modelo,  precio);
        this.Marca = marca;
        this.Modelo = modelo;
        this.Cilindrada = Cilindrada;
        this.Precio = precio;
    }

    @Override
    public String toString() {
        return "Marca: " + Marca + " // Modelo: " + Modelo +
                " // Cilindrada: " + Cilindrada + " // Precio: $" + String.format("%,.2f", Precio);
    }
}

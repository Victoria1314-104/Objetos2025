package ar.org.centro8.curso.java.ActividadNro2.entities;
// import ar.org.centro8.curso.java.ActividadNro2.entities.Vehiculo;

public class Auto extends Vehiculo{
    private int Puertas;

    public Auto(String Marca, String Modelo, int Puertas, double Precio) {
        super(Marca, Modelo, Precio);
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Puertas = Puertas;
        this.Precio = Precio;
    }

    @Override
    public String toString() {
        return "Marca: " + Marca + " // Modelo: " + Modelo +
                " // Puertas: " + Puertas + " // Precio: $" + String.format("%,.2f", Precio);
    }
    
}

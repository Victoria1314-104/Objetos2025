package ar.org.centro8.curso.java.ActividadNro2.test;

import ar.org.centro8.curso.java.ActividadNro2.entities.Auto;
import ar.org.centro8.curso.java.ActividadNro2.entities.Moto;
import ar.org.centro8.curso.java.ActividadNro2.entities.Vehiculo;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;

public class TestVehiculo {
    public static void main(String[] args) {
        List<Vehiculo>vehiculos=new ArrayList<>();
        vehiculos.add(new Auto("Peugeot","206",4,200000.00));
        vehiculos.add(new Moto("Honda", "Titan", "125c", 60000.00));
        vehiculos.add(new Auto("Peugeot", "208", 5, 250000.00));
        vehiculos.add(new Moto("Yamaha", "YBR", "160t", 80500.50));

        // Consulta 1
        vehiculos.stream().forEach(System.out::println);
        System.out.println("=============================");

        // Consulta 2
        double precioMin=vehiculos
        .stream()
        .min(Comparator.comparingDouble(Vehiculo::getPrecio))
        .get()
        .getPrecio();
        double precioMax=vehiculos
        .stream()
        .max(Comparator.comparingDouble(Vehiculo::getPrecio))
        .get()
        .getPrecio(); 
        vehiculos.stream()
                 .filter(vehiculo->vehiculo.getPrecio()==precioMax)
                 .forEach(v->System.out.println("Vehiculo más caro: "+ v.getMarca()+" "+v.getModelo()));
        vehiculos.stream()
                 .filter(vehiculo->vehiculo.getPrecio()==precioMin)
                 .forEach(v->System.out.println("Vehiculo más barato: "+ v.getMarca()+" "+v.getModelo()));
        vehiculos.stream()
                 .filter(vehiculo->vehiculo.getModelo().toLowerCase().contains("y"))
                 .forEach(v->System.out.println("Vehículo que contiene en el modelo la letra 'y': "+ v.getMarca()+" "+v.getModelo()+" "+v.getPrecio()));
        System.out.println("=============================");

        // Consulta 3
        vehiculos.stream()
                 .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                 .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
        System.out.println("=============================");

        // Consulta 4
        vehiculos.stream()
                 .sorted(Comparator.comparing(Vehiculo::getMarca).thenComparing(Vehiculo::getModelo).thenComparing(Vehiculo::getPrecio))
                 .forEach(System.out::println);
        
    }
}

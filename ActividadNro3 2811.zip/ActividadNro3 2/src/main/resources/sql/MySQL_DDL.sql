select version();
drop database if exists restaurante;
create database restaurante;
use restaurante;
drop table if exists proveedores;
drop table if exists insumos;
drop table if exists proveedor_insumos;
drop table if exists empleados;
drop table if exists turnos;
use restaurante;
-- -----------------------------------------------------
-- Table proveedores
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS proveedores (
  id_proveedores INT NOT NULL AUTO_INCREMENT ,
  nombre VARCHAR(45) NOT NULL,
  direccion VARCHAR(45) NOT NULL,
  telefono_proveedor CHAR(8) NOT NULL CHECK (telefono_proveedor REGEXP '^[0-9]{8}$'),
  PRIMARY KEY (id_proveedores))
;

-- -----------------------------------------------------
-- Table insumos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS insumos (
  id_insumos INT NOT NULL,
  producto VARCHAR(45) NOT NULL,
  cantidad_venta VARCHAR(45) NOT NULL,
  precio DECIMAL(10,2) NULL,
  stock INT NULL,
  PRIMARY KEY (id_insumos))

;

-- -----------------------------------------------------
-- Table proveedor_insumos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS proveedor_insumos (
  id_proveedores INT NOT NULL, 
  id_insumos INT NOT NULL,
  precio DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL,
  descripcion VARCHAR(100) NULL,
  PRIMARY KEY (id_proveedores, id_insumos),
  CONSTRAINT fk_proveedor_insumos_proveedores1
    FOREIGN KEY (id_proveedores)
    REFERENCES proveedores (id_proveedores)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_proveedor_insumos_insumos1
    FOREIGN KEY (id_insumos)
    REFERENCES insumos (id_insumos)
    ON DELETE CASCADE     
    ON UPDATE CASCADE
);

-- -----------------------------------------------------
-- Table turnos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS turnos (
  id_turno INT NOT NULL AUTO_INCREMENT,
  dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
  horario VARCHAR(45) NOT NULL,
  PRIMARY KEY (id_turno))
;

-- -----------------------------------------------------
-- Table empleados
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS empleados (
  id_empleado INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(45) NOT NULL check(length(nombre)>=3),
  apellido VARCHAR(45) NOT NULL check(length(apellido)>=3),
  fecha_ingreso DATE,
  direccion VARCHAR(100) NOT NULL,
  telefono CHAR(8) NOT NULL CHECK (telefono REGEXP '^[0-9]{8}$'),
  legajo VARCHAR(45) NOT NULL,
  id_turno INT NOT NULL,
  dia VARCHAR(20) NOT NULL,
  horario VARCHAR(20) NOT NULL,
  PRIMARY KEY (id_empleado)
;


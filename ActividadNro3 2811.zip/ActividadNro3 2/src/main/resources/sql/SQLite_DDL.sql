-- drop database if exists restaurante;
-- create database restaurante;
-- use restaurante;
drop table if exists proveedores;

drop table if exists insumos;

drop table if exists proveedor_insumos;

drop table if exists empleados;

drop table if exists turnos;
-- use restaurante;
-- -----------------------------------------------------
-- Table proveedores
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS proveedores (
    id_proveedores INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre VARCHAR(45) NOT NULL,
    direccion VARCHAR(45) NOT NULL,
    telefono_proveedor CHAR(8) NOT NULL CHECK (
        telefono_proveedor GLOB '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
    )
);

-- -----------------------------------------------------
-- Table insumos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS insumos (
    id_insumos INTEGER PRIMARY KEY AUTOINCREMENT,
    producto VARCHAR(45) NOT NULL,
    cantidad_venta VARCHAR(45) NOT NULL,
    precio DECIMAL(10, 2) NULL,
    stock INT NULL,
    id_proveedor int not null,
    foreign key (id_proveedor) REFERENCES proveedores (id_proveedores)
);

-- -----------------------------------------------------
-- Table proveedor_insumos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS proveedor_insumos (
    id_proveedores INT NOT NULL,
    id_insumos INT NOT NULL,
    precio DECIMAL(10, 2),
    stock INT,
    descripcion VARCHAR(100) NULL,
    PRIMARY KEY (id_proveedores, id_insumos),
    CONSTRAINT fk_proveedor_insumos_proveedores1 FOREIGN KEY (id_proveedores) REFERENCES proveedores (id_proveedores) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_proveedor_insumos_insumos1 FOREIGN KEY (id_insumos) REFERENCES insumos (id_insumos) ON DELETE CASCADE ON UPDATE CASCADE
);

-- -----------------------------------------------------
-- Table empleados
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS empleados (
    id_empleado INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL CHECK (length(nombre) >= 3),
    apellido TEXT NOT NULL CHECK (length(apellido) >= 3),
    fecha_ingreso TEXT NOT NULL,
    direccion TEXT NOT NULL,
    telefono TEXT CHECK (
        telefono GLOB '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
    ),
    legajo TEXT NOT NULL,
    dia TEXT NOT NULL CHECK (
        dia IN (
            'LUNES',
            'MARTES',
            'MIERCOLES',
            'JUEVES',
            'VIERNES'
        )
    ),
    horario TEXT NOT NULL CHECK (
        horario IN ('MAÑANA', 'TARDE', 'NOCHE')
    )
);
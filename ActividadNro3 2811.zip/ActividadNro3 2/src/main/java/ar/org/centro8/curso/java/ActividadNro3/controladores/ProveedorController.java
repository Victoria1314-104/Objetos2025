package ar.org.centro8.curso.java.ActividadNro3.controladores;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;
import ar.org.centro8.curso.java.ActividadNro3.repositories.ProveedorRepository;

@Controller
public class ProveedorController {
    private ProveedorRepository pr = new ProveedorRepository();
    private String mensaje= "Complete las celdas";

    @GetMapping("/proveedores")
    public String getProveedor(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar){
        Proveedor proveedor = new Proveedor();
        model.addAttribute("proveedor", proveedor);
        if (buscar.matches("\\d+")) {
            Proveedor encontrado = pr.getById_Proveedor(Integer.parseInt(buscar));
            model.addAttribute("proveedores", List.of(encontrado));
        } else {
            model.addAttribute("proveedores", pr.getLikeNombre(buscar));
        }
        model.addAttribute("mensaje",mensaje);
        return "proveedores";
    }

    @PostMapping("/guardarProveedor")
    public String guardarProveedor(@ModelAttribute Proveedor proveedor) {
        pr.save(proveedor);
        if (proveedor.getId_proveedor()>0) 
            mensaje = "Se guardo el proveedor. Su id es" + proveedor.getId_proveedor();
        else 
            mensaje = "No se guardo el proveedor";
        return "redirect:/proveedores";
    }
}

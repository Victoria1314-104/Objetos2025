package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;

public class TestEmpleado {
    public static void main(String[] args) {
        // LocalDate hoy = LocalDate.now();
        System.out.println("---empleado1---");
        Empleado empleado1 = new Empleado(1, "Nataly", "Agreste", "20/09/2025", "Calle", "Gerente", Dia.JUEVES,
                Horario.MAÑANA);
        System.out.println(empleado1);
    }
}

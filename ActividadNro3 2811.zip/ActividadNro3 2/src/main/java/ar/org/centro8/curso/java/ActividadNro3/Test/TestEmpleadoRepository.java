package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Empleado;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;
import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;
import ar.org.centro8.curso.java.ActividadNro3.repositories.EmpleadoRepository;

public class TestEmpleadoRepository {
    public static void main(String[] args) {
        EmpleadoRepository er = new EmpleadoRepository();

        Empleado empleado = new Empleado(34,
                "Victor",
                "Guerrin",
                "21/11/2021",
                "Calle",
                "12345678",
                "Gerente de Marketing",
                Dia.LUNES,
                Horario.NOCHE);
        er.save(empleado);
        System.out.println(empleado);

        System.out.println("-----------");
        er.getAll().forEach(System.out::println);

        System.out.println("---------------------remove-------");
        er.remove(er.getById_empleado(4));

        System.out.println("--------------------");
        er.getAll().forEach(System.out::println);

    }
}

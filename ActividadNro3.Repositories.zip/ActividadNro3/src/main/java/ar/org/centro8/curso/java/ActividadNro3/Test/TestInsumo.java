package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;

public class TestInsumo {
    public static void main(String[] args) {
        System.out.println("---insumo1---");
        Insumo insumo1 = new Insumo(2, "Morcilla", "kg", 2400.50, 10);
        System.out.println(insumo1);
    }
}

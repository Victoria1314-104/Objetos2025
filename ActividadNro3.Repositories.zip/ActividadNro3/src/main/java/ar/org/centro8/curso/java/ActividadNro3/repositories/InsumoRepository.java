package ar.org.centro8.curso.java.ActividadNro3.repositories;

import ar.org.centro8.curso.java.ActividadNro3.connectors.Connector;
import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class InsumoRepository {
    private Connection conn = Connector.getConnection();

    public void save(Insumo insumo) {
        if (insumo == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into insumos (producto, cantidad_venta, precio, stock) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, insumo.getProducto());
            ps.setString(2, insumo.getCantidad_venta());
            ps.setDouble(3, insumo.getPrecio());
            ps.setInt(4, insumo.getStock());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                insumo.setId_insumo(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Insumo insumo) {
        if (insumo == null)
            return;

        try (PreparedStatement ps = conn.prepareStatement("delete from insumos where id_insumos=?")) {
            ps.setInt(1, insumo.getId_insumo());
            ps.execute();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    public Insumo getById_Insumo(int id_insumo) {
        return getAll()
                .stream()
                .filter(i -> i.getId_insumo() == id_insumo)
                .findAny()
                .orElse(new Insumo());
    }

    public List<Insumo> getAll() {
        List<Insumo> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from insumos")) {
            while (rs.next()) {
                list.add(
                        new Insumo(
                                rs.getInt("id_insumos"),
                                rs.getString("producto"),
                                rs.getString("cantidad_venta"),
                                rs.getDouble("precio"),
                                rs.getInt("stock")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Insumo> getLikeProducto(String producto) {
        return getAll()
                .stream()
                .filter(i -> i.getProducto().toLowerCase().contains(producto))
                .toList();
    }

    public List<Insumo> getLikeCantidad_venta(String cantidad_venta) {
        return getAll()
                .stream()
                .filter(i -> i.getCantidad_venta().toLowerCase().contains(cantidad_venta))
                .toList();
    }

    public List<Insumo> getLikePrecio(double precio) {
        return getAll()
                .stream()
                .filter(i -> i.getPrecio() == precio)
                .toList();
    }

    public List<Insumo> getLikeStock(int stock) {
        return getAll()
                .stream()
                .filter(i -> i.getStock() == stock)
                .toList();
    }

}

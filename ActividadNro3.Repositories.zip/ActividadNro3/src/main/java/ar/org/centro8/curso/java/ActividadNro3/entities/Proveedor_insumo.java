package ar.org.centro8.curso.java.ActividadNro3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Proveedor_insumo {
    private Proveedor id_proveedor;
    private Insumo id_insumo;
    private double precio;
    private int stock;
    private String descripcion;
    
    public Proveedor_insumo(Proveedor id_proveedor, Insumo id_insumo, String descripcion) {
        this.id_proveedor = id_proveedor;
        this.id_insumo = id_insumo;
        this.descripcion = descripcion;
    }

    // @Override
    // public String toString() {
    //     return "Provedor_insumo [id_proveedor=" + id_proveedor.getId_proveedor() + ", id_insumo=" + id_insumo.getId_insumo() + ", precio=" + id_insumo.getPrecio() + ", stock="
    //             + id_insumo.getStock() + ", descripcion=" + descripcion + "]";
    // }




    
}

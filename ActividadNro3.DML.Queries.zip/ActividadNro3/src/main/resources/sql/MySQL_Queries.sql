use restaurante;
select
  id_proveedores,
  nombre,
  direccion,
  telefono_proveedor
from proveedores;

select
  id_insumos,
  producto,
  cantidad_venta,
  precio,
  stock
from insumos;

SELECT 
  p.id_proveedores,
  p.nombre AS proveedor,
  i.id_insumos,
  i.producto,
  i.precio,
  pi.descripcion
FROM proveedor_insumos pi
JOIN proveedores p ON pi.id_proveedores = p.id_proveedores
JOIN insumos i ON pi.id_insumos = i.id_insumos;

SELECT 
  id_turno,
  dia,
  horario
FROM turnos;

SELECT 
  id_empleado,
  nombre,
  apellido,
  fecha_ingreso,
  direccion,
  telefono,
  legajo,
  id_turno
FROM empleados;

SELECT 
  e.id_empleado,
  e.nombre,
  e.apellido,
  t.dia,
  t.horario
FROM empleados e
JOIN turnos t ON e.id_turno = t.id_turno
ORDER BY t.dia, e.apellido;

SELECT 
  id_empleado,
  nombre,
  apellido,
  fecha_ingreso
FROM empleados
WHERE fecha_ingreso >= DATE_SUB(NOW(), INTERVAL 7 DAY);

SELECT 
  p.nombre AS proveedor,
  COUNT(pi.id_insumos) AS cantidad_insumos
FROM proveedores p
LEFT JOIN proveedor_insumos pi ON p.id_proveedores = pi.id_proveedores
GROUP BY p.id_proveedores;

SELECT 
  id_insumos,
  producto,
  stock
FROM insumos
WHERE stock < 30;

SELECT 
  SUM(precio * stock) AS valor_total_stock
FROM insumos;

-- Eliminar un proveedor y sus insumos asociados (ON DELETE CASCADE)
DELETE FROM proveedores
WHERE nombre = 'Frutas del Valle';

-- Aumentar el precio del queso mozzarella un 10%
UPDATE insumos
SET precio = precio * 1.10
WHERE producto = 'Queso mozzarella';

-- Cambiar el turno de Carlos López al viernes
UPDATE empleados
SET id_turno = 5
WHERE nombre = 'Carlos' AND apellido = 'López';
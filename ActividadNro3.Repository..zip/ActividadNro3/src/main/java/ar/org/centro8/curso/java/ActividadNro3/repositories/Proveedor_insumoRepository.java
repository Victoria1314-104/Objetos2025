package ar.org.centro8.curso.java.ActividadNro3.repositories;

import ar.org.centro8.curso.java.ActividadNro3.connectors.Connector;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor_insumo;
import ar.org.centro8.curso.java.ActividadNro3.entities.Insumo;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Proveedor_insumoRepository {
    private Connection getConnection(){
        return Connector.getConnection();
    }
    // private Connection conn = Connector.getConnection();

    public void save(Proveedor_insumo proveedor_insumo) {
        if (proveedor_insumo == null)
            return;

        try (Connection conn = Connector.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO proveedor_insumos (precio, stock, descripcion) VALUES (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setDouble(1, proveedor_insumo.getPrecio());
            ps.setInt(2, proveedor_insumo.getStock());
            ps.setString(3, proveedor_insumo.getDescripcion());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                proveedor_insumo.getId_proveedor().setId_proveedor(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Proveedor_insumo proveedor_insumo) {
        if (proveedor_insumo == null)
            return;

        try (Connection conn = Connector.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM proveedor_insumos WHERE id_proveedores= ?")) {
            ps.setInt(1, proveedor_insumo.getId_proveedor().getId_proveedor());  // inspiracion de AI
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Proveedor_insumo getById_proveedor(int id_proveedor) {
        return getAll()
                .stream()
                .filter(ip->ip.getId_proveedor().getId_proveedor() == id_proveedor) //toknow. getId_proveedor()
                .findAny()
                .orElse(null);
    }

    public Proveedor_insumo getLikeId_Insumo(int id_insumo) {
        return getAll()
                .stream()
                .filter(i->i.getId_insumo().getId_insumo() == id_insumo)
                .findAny()
                .orElse(null);
    }

    public List<Proveedor_insumo> getAll() {
        List<Proveedor_insumo> list = new ArrayList();
        try (Connection conn = Connector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("select * from proveedor_insumos")){
            ProveedorRepository pr= new ProveedorRepository();  // ---AI
            InsumoRepository ir= new InsumoRepository();        // ---AI
            while (rs.next()) {
                int id_proveedor = rs.getInt("id_proveedores");    // ---AI
                int id_insumo = rs.getInt("id_insumos");           // ---AI
                Proveedor proveedor = pr.getById_Proveedor(id_proveedor);      // ---AI
                Insumo insumo = ir.getById_Insumo(id_insumo);    //---AI
                list.add(
                    // new Proveedor_insumo(proveedor,
                    //                 rs.getInt("id_insumos"),
                    //                 rs.getDouble("precio"),
                    //                 rs.getInt("Stock"),
                    //                 rs.getString("descripcion")));

                    new Proveedor_insumo(proveedor,
                                        insumo,
                                        // rs.getDouble("precio"),
                                        // rs.getInt("stock"),
                                        rs.getString("descripcion")));  //---AI
            }           
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Proveedor_insumo> getLikePrecio(double precio){
        final double EPSILON = 0.01;
        return getAll()
                .stream()
                .filter(pr->Math.abs(pr.getId_insumo().getPrecio()-precio)<EPSILON)
                .toList(); 
    }

    public List<Proveedor_insumo> getLikeStock(int stock) {
        return getAll()
                .stream()
                .filter(s->s.getId_insumo().getStock() == stock)
                .toList();
    }

    public List<Proveedor_insumo> getLikeDescripcion (String descripcion) {
        return getAll()
                .stream()
                .filter(d->d.getDescripcion().toLowerCase().contains(descripcion))
                .toList();
    }
}


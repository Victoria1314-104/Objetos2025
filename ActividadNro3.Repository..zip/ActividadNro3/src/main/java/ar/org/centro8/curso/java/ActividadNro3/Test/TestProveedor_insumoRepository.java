package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor_insumo;
import ar.org.centro8.curso.java.ActividadNro3.repositories.Proveedor_insumoRepository;

public class TestProveedor_insumoRepository {
    public static void main(String[] args) {
        Proveedor_insumoRepository pir = new Proveedor_insumoRepository();

        Proveedor_insumo proveedor_insumo = new Proveedor_insumo(new Proveedor(67,"Salchicha", null, null), null, null);
        pir.save(proveedor_insumo);
        System.out.println(proveedor_insumo);

        pir.remove(pir.getById_proveedor(5));

        System.out.println("--------------------");
        pir.getAll().forEach(System.out::println);

        System.out.println("---------------------");
        pir.getLikeDescripcion("za").forEach(System.out::println);;
    }
}

package ar.org.centro8.curso.java.ActividadNro3.repositories;

import ar.org.centro8.curso.java.ActividadNro3.connectors.Connector;
import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProveedorRepository {
    private Connection conn = Connector.getConnection();

    public void save(Proveedor proveedor) {
        if (proveedor == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into proveedores (nombre,direccion,telefono_proveedor) values(?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, proveedor.getNombre());
            ps.setString(2, proveedor.getDireccion());
            ps.setString(3, proveedor.getTelefono_proveedor());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                proveedor.setId_proveedor(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Proveedor proveedor) {
        if (proveedor == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from proveedores where id_proveedores=?")) {
            ps.setInt(1, proveedor.getId_proveedor());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Proveedor getById_Proveedor(int id_proveedor) {
        return getAll()
                .stream()
                .filter(p -> p.getId_proveedor() == id_proveedor)
                .findAny()
                .orElse(new Proveedor());
    }

    public List<Proveedor> getAll() {
        List<Proveedor> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from proveedores")) {
            while (rs.next()) {
                list.add(
                        new Proveedor(
                                rs.getInt("id_proveedores"),
                                rs.getString("nombre"),
                                rs.getString("direccion"),
                                rs.getString("telefono_proveedor")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Proveedor> getLikeNombre(String nombre) {
        return getAll()
                .stream()
                .filter(p -> p.getNombre().toLowerCase().contains(nombre))
                .toList();
    }

    public List<Proveedor> getLikeDireccion(String direccion) {
        return getAll()
                .stream()
                .filter(p -> p.getDireccion().toLowerCase().contains(direccion))
                .toList();
    }

    public List<Proveedor> getLikeTelefono(String telefono_proveedor) {
        return getAll()
                .stream()
                .filter(p -> p.getTelefono_proveedor().toLowerCase().contains(telefono_proveedor))
                .toList();
    }

}

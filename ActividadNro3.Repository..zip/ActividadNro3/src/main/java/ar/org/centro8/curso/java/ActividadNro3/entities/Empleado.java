package ar.org.centro8.curso.java.ActividadNro3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

import ar.org.centro8.curso.java.ActividadNro3.enums.Horario;
import ar.org.centro8.curso.java.ActividadNro3.enums.Dia;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Empleado {
    private int id_empleado;
    private String nombre;
    private String apellido;
    private String fecha_ingreso;
    private String direccion;
    private int telefono;
    private String legajo;
    private Dia dia;
    private Horario horario;

    

    public Empleado(int id_empleado, String nombre, String apellido, String fecha_ingreso, String direccion,
            String legajo, Dia dia, Horario horario) {
        this.id_empleado = id_empleado;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fecha_ingreso = fecha_ingreso;
        this.direccion = direccion;
        this.legajo = legajo;
        this.dia = dia;
        this.horario = horario;
    }

}



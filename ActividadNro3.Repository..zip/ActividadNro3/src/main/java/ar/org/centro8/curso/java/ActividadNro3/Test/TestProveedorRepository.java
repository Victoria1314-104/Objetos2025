package ar.org.centro8.curso.java.ActividadNro3.Test;

import ar.org.centro8.curso.java.ActividadNro3.entities.Proveedor;
import ar.org.centro8.curso.java.ActividadNro3.repositories.ProveedorRepository;

public class TestProveedorRepository {
    public static void main(String[] args) {
        ProveedorRepository pr = new ProveedorRepository();

        Proveedor proveedor = new Proveedor(99, "Diarco", "Av.La plata 100", "1122334455");
        pr.save(proveedor);
        System.out.println(proveedor);

        pr.remove(pr.getById_Proveedor(3));

        System.out.println("-------------------------------");
        pr.getAll().forEach(System.out::println);

        System.out.println("-----------------------------");
        pr.getLikeNombre("a").forEach(System.out::println);
    }
}

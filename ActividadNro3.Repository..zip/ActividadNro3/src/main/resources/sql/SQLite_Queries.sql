select
  id_proveedores,
  nombre,
  direccion,
  telefono_proveedor
from proveedores;

select
  id_insumos,
  producto,
  cantidad_venta,
  precio,
  stock
from insumos;

SELECT 
  p.id_proveedores,
  p.nombre AS proveedor,
  i.id_insumos,
  i.producto,
  i.precio,
  pi.descripcion
FROM proveedor_insumos pi
JOIN proveedores p ON pi.id_proveedores = p.id_proveedores
JOIN insumos i ON pi.id_insumos = i.id_insumos;


SELECT * FROM empleados;

SELECT 
  id_empleado,
  nombre,
  apellido,
  fecha_ingreso
FROM empleados
WHERE fecha_ingreso >= datetime('now', '-7 days');

SELECT 
  p.nombre AS proveedor,
  COUNT(pi.id_insumos) AS cantidad_insumos
FROM proveedores p
LEFT JOIN proveedor_insumos pi ON p.id_proveedores = pi.id_proveedores
GROUP BY p.id_proveedores;

SELECT 
  pi.id_insumos,
  i.producto,
  pi.stock
FROM proveedor_insumos AS pi
JOIN insumos AS i ON pi.id_insumos = i.id_insumos
WHERE pi.stock < 30;

SELECT 
  i.producto,
  SUM(pi.precio * pi.stock) AS valor_total_stock
FROM proveedor_insumos pi
JOIN insumos i ON pi.id_insumos = i.id_insumos
GROUP BY i.id_insumos;

SELECT 
  SUM(precio * stock) AS valor_total_stock
FROM proveedor_insumos;

-- Eliminar un proveedor y sus insumos asociados (ON DELETE CASCADE)
DELETE FROM proveedores
WHERE nombre = 'Frutas del Valle';

-- Aumentar el precio del queso mozzarella un 10%
UPDATE insumos
SET precio = precio * 1.10
WHERE producto = 'Queso mozzarella';
